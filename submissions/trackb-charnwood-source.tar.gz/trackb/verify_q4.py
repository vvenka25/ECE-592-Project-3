#!/usr/bin/env python3
"""Verify preserved Q4 files; only project README and AI log may be revised."""
import hashlib
import json
import tarfile
from pathlib import Path

root=Path(__file__).resolve().parents[1]
record=json.loads((root/'preserved/q4-20261106.sha256.json').read_text())
archive=root/'preserved/q4-20261106.tar.gz'
assert hashlib.sha256(archive.read_bytes()).hexdigest()==record['archive_sha256'],'Q4 archive changed'
mutable={'README_Track_B.md','AI_USE_LOG.md'}
checked=archived_only=0
with tarfile.open(archive) as tar:
    for name,digest in record['files'].items():
        if name in mutable:continue
        path=root/name
        if path.exists():data=path.read_bytes()
        elif name.startswith('build/'):
            # Source ZIPs keep the original binaries/build outputs in the
            # immutable archive instead of placing them in the active build.
            member=tar.getmember(name);assert member.isfile()
            data=tar.extractfile(member).read();archived_only+=1
        else:raise AssertionError('Missing preserved Q4 file: '+name)
        assert hashlib.sha256(data).hexdigest()==digest,'Preserved Q4 file changed: '+name
        checked+=1
print(f'{checked} preserved Q4 files unchanged; original archive hash verified; {archived_only} build files verified from archive only. Project README/AI log updates are separate.')
