# Homework 3 — Track B — 105 points

**Q1, Q2, Q3, Q4, Q5, Q8 — 105 points.** Q4 is completed and preserved; Q6 is dropped.

See [the current project README](README_Track_B.md), [task list](TASKS.md), [report outline](report/OUTLINE.md), and [new benchmark methods/reproduction](trackb/METHODS.md).

Implementation order: **Q3 → Q1 → Q2 → Q5 → Q8**. The new suite is isolated under `trackb/` and passes native/hardware-SGX semantic, byte and timer checks. [Two-machine findings](RESULTS_TRACK_B_COMPARISON.md) cover every selected question; the missing Charnwood Q4 comparison uses unchanged source and preserves completed Artemisia work.

See the [report PDF](report/report.pdf) and [AI-use log](AI_USE_LOG.md). Q5 reports effective integer-GPR destination-pressure bounds, with total PRF conversion unproved. Q8 native miss costs are about 9 active core cycles on Charnwood and 7 on Artemisia; enclave miss attribution remains unqualified.
