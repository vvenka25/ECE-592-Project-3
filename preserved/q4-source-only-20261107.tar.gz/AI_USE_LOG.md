# AI assistance record

Retained background: AI assisted the earlier ROB mechanism discussion, reference-code review and Track A planning; those were not course-machine capacity measurements. AI assisted the Track B Q4/Q5/Q6 plan, platform-record interpretation, and the SGX sample commands described in README_Track_B.md. The user's Artemisia sample execution established hardware debug SGX functionality.

2026-11-06: Codex read README_Track_B.md and generated the ROB assembly generator, shared pointer-cycle initialization, native runner, SGX EDL/entry/config/build, raw CSV output, metadata collection, plotting script and verification tests. It compiled native and hardware-mode enclave targets and signed the debug enclave with the installed SDK. It debugged test disassembly parsing. Functional verification and limitations are recorded in ROB_BENCHMARK.md; no ROB capacity estimate is established by this implementation work. The student must review the assembly, dependency/spacing accounting, timer boundaries, EPC/footprint controls, and test the custom enclave on Artemisia before using measurements in the report.

2026-11-06 follow-up: After the user reported an enclave smoke-test failure,
Codex reproduced the SDK placeholder runtime error and used `ldd` to identify
an incorrect SDK runtime path embedded by the generated Makefile. It removed
that path, verified selection of `/lib64/libsgx_urts.so.2`, made Makefile changes
trigger a host-executable rebuild, and added visible subprocess output plus
operation-specific SGX errors. Native checks passed again. Hardware execution
still requires the user's SGX-enabled environment; this sandbox has no SGX
device. No heap or benchmark kernel changes were made for this repair.

2026-11-06 methodology revision: Codex inspected the saved Artemisia v1 CSVs
and identified repeated-prefix cache reuse, correlated ring layouts and a
half-footprint dependent control. It implemented method rob-v2: persistent
cursors, independent shuffles, a dependent link cycle covering the same lines,
full-traversal/data and selected-kernel warm-up, native mmap page advice,
stride/NOP-width/alignment controls, randomized condition order, raw
fault/context-switch diagnostics, source/build identifiers and memory snapshots.
It added CPUID/preflight records and a staged experiment runner with truthful
sibling-control labels, optional NUMA binding and optional whole-process perf
counts, plus plots that preserve method/run/control distinctions and sample
order. It consulted Intel and kernel primary documentation and Wong's original
measurements to define controls and inference limits. Native semantic/code,
CSV/mapping tests and a tiny /tmp campaign passed; SGX v2 compiled and signed
but cannot be hardware-run in the coding sandbox. The original v1 raw results
remain unchanged. The student must review the new accounting and staged gates,
validate v2 hardware execution, obtain course-machine calibration/controls, and
justify any final capacity inference independently of specifications.

2026-11-06 build follow-up: The calibration runner rejected a stale build before
collecting samples. Codex inspected timestamps and make's dependency output:
the unsigned enclave was newer than its signed counterpart. It updated
--execute to run make for the selected targets, then verify freshness before
hashing binaries or creating the result directory. This preserves the check
against mixing source/build versions while handling rebuild/sign/link work
automatically. No earlier experiment data was modified.

2026-11-06 completed-calibration review: The user ran ten rob-v2 calibration
jobs on Artemisia, including hardware-debug enclaves, and saved 300 samples.
Codex inspected CSVs, manifests, logs, smaps, numa_maps and platform snapshots;
verified current binary hashes against the recorded identities; generated a
reproducible analyzer, summary CSV, mapping/input-hash audit and PNG/PDF plots;
and recorded the findings in results/v2-calibration/review/REVIEW.md. It found
approximately twofold independent-chain overlap, verified native 4K/node-0
mapping, and identified remaining sample drift and uncontrolled sibling
activity. It selected 256 MiB only as a provisional blocker and recommended
an order-changed independent repetition. No samples were discarded and no ROB
capacity was inferred. EPC residency/node placement cannot be concluded from
SGX device mapping RSS/numa records. The student must review these distinctions
and the uncertainty before using the results in the report.

2026-11-06 repeat calibration review: The user completed the second ten-job
calibration with order seed 2. Codex reviewed the additional 300 samples and
memory audits, checked matched binary identities and workload parameters,
and added analysis/compare_calibrations.py plus per-campaign and comparison
CSV/JSON/PNG/PDF artifacts. At 256 MiB the repeat's early/late changes are below
0.4% in all four conditions, and medians differ from the first campaign by at
most 2.44%; the 128 MiB native dependent drift persists. Codex selected 256 MiB
as a working baseline for the next prefetch/layout sensitivity stage, retained
all 600 samples (66 with context-switch deltas), and documented uncontrolled
sibling activity and attribution limits. It prepared and checked the eight-job
next-stage command without running the hardware campaign in the coding
sandbox. No ROB capacity was inferred. Original raw data and benchmark
binaries were not changed by this review.

2026-11-06 pointer-layout review: The user completed eight native/hardware-debug
SGX spacing sweeps, producing 7,920 samples across three pointer seeds and two
node spacings. Codex added analysis/review_sweep.py and generated descriptive
CSV/JSON and PNG/PDF artifacts. All eight cases show their largest independent
adjacent median increase between the tested NOP spacings 480 and 512, and
independent/dependent medians converge after the step. The step also persists
in minima and separately labeled unflagged-sample sensitivity medians. All
samples were retained in the primary results, including ten with minor-fault
deltas and 2,103 with context-switch deltas. Native 4K/node-0 mapping and the
stride-128 span increase were checked; matching calibration binary hashes were
verified. The interpretation is a surviving instruction-window candidate, not
an exact ROB capacity or proof that prefetching is absent. Codex prepared the
three-job translation control as the next user-run experiment. No benchmark
code or original raw observations were changed by this review.

2026-11-06 translation-control repair: The user completed three translation
jobs (2,970 samples). Codex reviewed the raw data and actual mappings, finding
only 6144/262144 KiB AnonHugePages in the advised native mapping. It labeled
this a partial/inconclusive full-page-size control, retained all raw data and
archived the preceding sources under its review directory. It consulted Linux
THP/madvise documentation and kernel UAPI, added native aligned synchronous
MADV_COLLAPSE with full-backing checks before/after measurement, and changed
the translation stage default to collapse while retaining an advice-only
reproduction option. Native fault-injection tests reject both allocation
failure and falsely reported success with incomplete backing; a real 8 MiB
check passed, and a separate 256 MiB sandbox native probe verified full THP at
both boundaries. This probe is functional setup evidence, not a paired NUMA
controlled capacity result. Native and SGX builds compile/sign and shared
kernel bytes remain matched. A fresh three-condition user-run hardware cohort
is required after the new build identity; no translation-insensitivity or ROB
capacity conclusion was inferred from the partial advice run.

2026-11-06 NUMA-specific allocation follow-up: The user completed a local
hardware-enclave baseline (990 samples) before native MADV_COLLAPSE failed
under bind:0. Codex inspected the saved earlier unbound probe and found
22 MiB on node 0 and 234 MiB on node 1, explaining why that success had not
established local allocation feasibility. It ran short, explicitly bound
native allocation checks: node-0 64/128/256 MiB failed, node-1 256 MiB passed
full backing and placement checks. These are functional allocation diagnostics,
not capacity results. Codex then executed two complete native page-policy
sweeps on CPU 1 with both mappings bound to node 1 (1,980 samples); full THP
versus zero THP and node-1 placement were verified at both boundaries. The
coarse 480->512 overlap-loss step persists in both page policies. This remote
control remains separate from local/enclave timing comparisons. It updated
the analysis helper to review explicitly selected completed jobs of an
incomplete campaign with clear labels, and to plot native-only cohorts without
inventing enclave data. The noisy partial enclave run, original failure, and
all observations were retained. Source/binaries were not changed by this
follow-up; the next stage is local 4K instruction-width/alignment controls.

2026-11-06 instruction-delivery review: The user completed 16 frontend jobs
(15,840 samples), with matched preceding binary identities. Codex reviewed
one-/two-byte NOP encodings and loop offsets 0/16/32 at 16 KiB and 256 MiB,
checked native 4K/node-0 placement and raw parameters, and retained all samples,
including 18 with minor faults and 2,668 with context-switch deltas. All eight
large-footprint curves preserve the largest independent timing step between
sampled N=480 and N=512 in medians, minima, and separately labeled unflagged
medians. Small-footprint curves show no comparable step. Elevated baseline
and isolated timings remain documented rather than removed or attributed to
an unmeasured cause. Codex extended analysis/review_sweep.py with separate
footprint plots, parameter validation and sensitivity CSVs, then exercised it
on the frontend, native-only and incomplete-campaign data. Benchmark sources,
binaries and original observations were unchanged. The result supports a
surviving instruction-window candidate, not an exact ROB count. Codex prepared
and checked the eight-job overhead stage in planning mode; the user must run
its enclave cases in the hardware-enabled shell. Overhead and finer/repeated
spacing measurements remain before capacity inference.

2026-11-06 overhead review: The user completed eight batch-length controls
(240 samples), with the same binary identities as the frontend campaign.
Codex added analysis/review_overhead.py, validated raw parameters/sample IDs,
audited native 4K/node-0 placement, and retained every observation. Zero-work
controls remain in total TSC ticks per invocation, with blank per-load fields.
The measured native/SGX zero-work medians are about 70–74/10,758–10,764 ticks.
At 100,000 iterations the SGX zero-work scale is about 0.054 ticks/load;
long-batch slopes support dilution of this mostly fixed invocation cost in
the fast-load control. Primary timings remain uncorrected, and subtraction
diagnostics are explicitly labeled. The campaign records no migration,
ordinary faults or context switches but does not establish interrupt/AEX
absence, controlled sibling activity, or complete large-footprint batch
independence. Codex generated CSV/JSON and PNG/PDF artifacts, checked syntax
and actual-data invariants, and prepared the fine N=448..576 step-4 command
in planning mode. Existing full-range controls supply its coarse bracket;
an independent repeat and accounting remain before a capacity conclusion.
No benchmark source, binary, or original sample was changed by this review.

2026-11-06 first fine-spacing review: The user completed two fine jobs
(1,980 samples) over N=448..576 in steps of four, with matching preceding
binary hashes. Codex reused analysis/review_sweep.py to summarize all samples
and generate CSV/JSON and PNG/PDF artifacts. Both environments have a partial
independent timing rise at N=496 and near-convergence with the dependent
control at N=500. The largest adjacent step is 496->500 in medians, minima,
and separately labeled unflagged medians; the broader observed transition
region is 492–500. Codex checked the raw observations at these points and
native 4K/node-0 mapping. All samples remain included, including six native
dependent N=516 samples with 20 minor-fault increments and 524 samples with
context-switch deltas. Significant SGX variability is retained and is not
assigned an unmeasured cause or interpreted as additional capacity bounds.
The review distinguishes NOP spacing and the loop's 2N+4 architectural
instructions from an inferred total ROB-entry count. Codex prepared and
checked the matched fine repeat with order seed 2 in planning mode, updated
the experiment status, and retained original data and benchmark binaries.
No exact ROB capacity or independent replication has yet been established.

2026-11-06 fine-repeat consolidation: The user completed the two order-seed-2
repeat jobs (1,980 additional samples). Codex reviewed the raw evidence and
verified matching workload/binary identities, reused the sweep analyzer,
and added analysis/compare_sweeps.py to compare campaigns without pooling.
It generated overlaid curves, selected raw-transition sample plots, per-point
CSV comparisons, global-step diagnostics and hashed mapping/input audits.
The previously selected 492–500 transition region repeats in native and SGX,
but the repeat enclave's largest median/unflagged-median step is an isolated
544->548 peak, not 496->500; the minimum diagnostic still selects 496->500.
Codex corrected its initial commentary about that global maximum and retained
the peak with no cause assigned. All 3,960 fine observations remain included,
including 16 with 115 minor-fault increments and 1,065 with context-switch
deltas. Native 4K/node-0 mapping and separated raw 492/496/500 timing ranges
were checked. Codex consolidated ROB_RESULTS_ARTEMISIA.md, distinguishing the
effective NOP-spacing/window result from total ROB entries, and stopped the
routine Artemisia run sequence for this claim. It checked analysis syntax,
actual-data invariants and evidence hashes; benchmark code/binaries and raw
data were unchanged. No new benchmark campaign was executed. The second
course-machine result, PRF/TLB work and final assignment deliverable remain
separate outstanding work.
