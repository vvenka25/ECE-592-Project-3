# Homework 3 - Track B: Fresh Project Plan

## Decision and current status

The project is now Track B. Work individually, disclose AI assistance, and understand and explain all submitted work. This plan supersedes the Track A work plan for the new implementation.

The initial shared native/SGX ROB benchmark is now implemented; see `ROB_BENCHMARK.md` for build, validation status, and reproduction instructions. The current implementation is method `rob-v2`, with staged calibration and controls; saved Artemisia v1 curves are exploratory and must not be pooled with v2. The Artemisia control sequence and fine repeat are complete, with a repeated effective instruction-window transition over N=492–500 in native and SGX execution. See `ROB_RESULTS_ARTEMISIA.md`; exact total ROB capacity and a second-machine result remain unestablished. Earlier ROB discussions and reference-code observations are background, not measured course-machine results. Do not present the reference benchmark or the prior static checks as a completed experiment.

Assignment authority: the supplied `Homework_3.pdf`, pages 2-4. The printed deadline is November 3, 2026, at 11:59 PM Eastern; no extension or changed submission deadline is assumed by this plan.

## 1. Working selection: 100 points

The proposed starting scope contains three related capacity experiments:

| Question | Requirement | Points | Planned output |
| --- | --- | ---: | --- |
| Q4 | Reverse engineer ROB size. | 30 | Timing curves, inferred capacity/range, and evidence supporting ROB attribution on two machines. |
| Q5 | Reverse engineer physical register file size; identify the register class. | 35 | Explicit integer or floating-point/vector register-class selection, measured allocation limit, and explanation of what that implies about PRF size on two machines. |
| Q6 | Reverse engineer the number of TLB levels and the size of each level. | 35 | Translation-capacity experiment, evidence for the inferred levels/capacities, and limitations on two machines. |
| **Total** | **Meets the minimum selected scope.** | **100** | **Three exercises, each measured on two course machines.** |

Why start here: ROB and PRF experiments can share infrastructure, and TLB capacity is a separate focused experiment that can share timing, run metadata, raw-data collection, and plotting. Choosing three exercises reduces the number of separate report topics; it is **not** a guarantee that all three are easy to isolate experimentally. PRF attribution and distinguishing TLB levels require careful controls.

This is a working selection. Validate the chosen machines and measurement feasibility before committing substantial implementation time. If a target cannot be isolated, revise the exercise combination deliberately and keep its total at least 100 points. Do not silently replace an unsupported experiment with a published specification.

The report's first page must list the final selected question numbers and their total points. A 100-point selection represents available credit, not an automatic earned grade.

## 2. Track B requirements

- Select exercises totaling **at least 100 points**. The handout offers 300 available points; completing all exercises is not required.
- For **every selected exercise**, run the experiment on **two course machines** and present the results side by side. The same two machines may be used across the three exercises.
- Briefly explain the method and differences between the two machines' results.
- Identify each tested machine's CPU model and microarchitecture.
- Include a relevant code snippet for each experiment and explain what is tested, how the experiment works, what is measured, and how the observations support the conclusion.
- Support conclusions with repeated measurements, plots, and short explanations.
- Keep measured findings separate from published specifications.
- Document unsupported features and access limitations.
- Complete the enclave comparison where support/access is available, as described below.
- Include an AI-use log because AI assistance is being used. Understand and be able to explain all submitted code and analysis.
- Submit a ZIP containing the PDF report, source code, raw data, plotting scripts, and reproduction instructions.
- Keep cache and prefetcher reverse engineering, including DMPs, outside the selected research scope.

Track B does **not** require the broader eight-machine sweep, year-sorted trend analysis, or paper-style report required by Track A. A clear exercise-by-exercise report is appropriate. Those three scope reductions do not remove the shared evidence, enclave, or packaging requirements.

## 3. Preferred machines: Charnwood and Artemisia

**Recommended pair:** use Charnwood for the older Skylake baseline and Artemisia for a newer Sapphire Rapids comparison and the initial SGX hardware-mode checks. Crux remains a fallback, but the user's current Crux session failed the SGX device read/write permission test.

The user supplied CPU records for all three hosts. Hardware-family identification is checked against Intel sources; runtime configuration comes from the supplied output. No ROB, PRF, or TLB capacity has been measured.

| Item | Charnwood | Artemisia | Crux (fallback) |
| --- | --- | --- | --- |
| CPU model | Core i7-6700 @ 3.40 GHz | Xeon Gold 5420+ | Core i7-9700 @ 3.00 GHz |
| CPU family/model/stepping | 6 / 94 / 3 | 6 / 143 / 8 | 6 / 158 / 13 |
| Intel product family/code name | Skylake | 4th Gen Xeon Scalable / Sapphire Rapids | Coffee Lake |
| Introduction, reference only | Q3 2015 | Q1 2023 | Q2 2019 |
| ISA | x86-64 | x86-64 | x86-64 |
| Sockets / physical cores total | 1 / 4 | 2 / 56 (28 per socket) | 1 / 8 |
| Logical CPUs present / online | 8 / 8 | 112 / 111; CPU 68 is offline | 8 / 8 |
| Threads per core | 2 | 2 | 1 |
| NUMA nodes | 1 | 2 | 1 |
| L2 per core from reported totals | 256 KiB | 2 MiB | 256 KiB |
| L3 from reported totals | 8 MiB, one instance | 105 MiB total across two instances; 52.5 MiB per instance | 12 MiB, one instance |
| SGX CPU flags | `sgx`; `sgx_lc` not shown | `sgx`, `sgx_lc` | `sgx`, `sgx_lc` |
| Current-user enclave device check | Not performed | Read/write access test passed | Read/write access test failed |
| SDK installation / environment | Not checked | SDK confirmed at `/opt/intel/sgxsdk`; hardware sample built against it after environment setup | No SDK tools resolved on the earlier PATH |
| Successful hardware enclave execution | Not demonstrated | **Confirmed: Intel SampleEnclave and custom ROB-v2 calibration, hardware debug mode** | Not demonstrated |
| Measured ROB / PRF / TLB capacities | Not measured | Not measured | Not measured |

Artemisia's L1 aggregate sizes are rounded in the supplied `lscpu` output. Do not divide those rounded values and present the result as an exact per-core capacity; collect exact cache-instance information if needed for experimental controls. The reported L3 total is a two-socket aggregate, not a single 105 MiB cache attached to one core.

### Implementation implications

- Use a shared x86-64 native backend across these hosts. Keep the common instruction subset unless a separately labeled variant requires newer features.
- Use TSC ticks with a separately documented measurement-ordering protocol.
- On Charnwood and Artemisia, identify the SMT sibling and record whether its activity is controlled. Do not assume sibling CPU numbering from a previous machine.
- On Artemisia, bind the benchmark to one permitted online logical CPU and arrange allocation/first touch on its local NUMA node. Record CPU and memory placement. Do not select offline CPU 68.
- Artemisia node 0 is reported as CPUs `0-27,56-67,69-83`; node 1 is `28-55,84-111`. These are supplied topology observations, not proof that the current account may reserve every listed CPU.
- The much larger cache resources on Artemisia require checking the true memory footprint/blocker delay. A workload that reaches DRAM on Charnwood need not do so on Artemisia.
- Avoid interpreting a socket-count, thread-count, or MHz difference as a measured ROB/PRF/TLB difference. Each selected quantity must be inferred experimentally.

### SGX hardware execution - confirmed on Artemisia

The user loaded the installed SDK environment, copied Intel's SampleEnclave into a new home-directory workspace, built it with `SGX_MODE=HW SGX_DEBUG=1`, and ran `./app`. The supplied output includes:

```text
The project has been built in debug hardware mode.
Info: SampleEnclave successfully returned.
```

This is functional evidence of a successfully executed **hardware-mode debug enclave**, beyond the earlier device-permission preflight. It establishes that the installed SDK, native compiler/linker path, signing, SGX runtime, device access, and hardware enclave initialization/execution were sufficient for this sample. The sample alone did not establish that the custom benchmark kernels, timers, or memory sizes worked inside an enclave; the later ROB-v2 calibration supplies that separate execution evidence.

| Setup item | Observed value |
| --- | --- |
| Host | Artemisia |
| SDK location | `/opt/intel/sgxsdk` |
| Environment setup | `source /opt/intel/sgxsdk/environment` |
| Sample workspace | `/home/vvenka25/sgx-check.YGhd1f/SampleEnclave` |
| Build settings | `SGX_MODE=HW SGX_DEBUG=1` |
| Signed enclave | `enclave.signed.so` |
| Debug configuration | `DisableDebug=0` |
| Maximum stack setting | `0x40000` = 256 KiB |
| Maximum heap setting | `0x100000` = 1 MiB |
| TCS setting | 10 |
| Sample's reported total required memory | 4,169,728 bytes, or 4072 KiB |
| Functional result | Sample enclave successfully returned |
| Exact SDK/runtime/compiler versions | Still to record; do not infer SDK version from file dates |

The memory figure is the sample's requirement, **not the machine's EPC capacity**. Benchmark memory requirements will need their own enclave configuration.

The redundant-declaration diagnostics were compiler warnings; linking, signing, and execution completed successfully. The SGX2 dynamic-feature message describes the chosen sample configuration and did not prevent execution. A test signing key was generated for this debug sample.

For the custom ROB/PRF benchmark, prefer instruction variants assembled at build time and linked into native and enclave binaries. Do not assume the reference benchmark's runtime writable/executable code generation transfers unchanged into the confirmed enclave configuration. Use the same conceptual kernels and accounting for the paired comparison and document differences.

Crux has `/dev/sgx_enclave` owned by `root:sgx` with group read/write permissions, but the user's current account failed the access test. Its restricted `/dev/sgx_provision` is not itself a blocker for an ordinary non-provisioning benchmark enclave. Retain the permission failure as an access limitation unless the administrator changes it.

Intel documents that the mainline Linux SGX driver requires configured Flexible Launch Control (FLC). Charnwood's missing `sgx_lc` in the supplied list does not prove that no legacy SGX path could exist, but Artemisia is now the preferred host for the initial modern-stack check. No lab firmware/driver changes are part of this preflight.

### Remaining metadata and implementation work

Load the SDK environment in each new Artemisia shell used for SGX builds:

```bash
source /opt/intel/sgxsdk/environment
```

Hardware-enclave execution is confirmed for both the Intel sample and the custom ROB-v2 calibration. The user completed two native/enclave calibration campaigns on Artemisia (600 samples total); see `results/v2-calibration-repeat/review/REVIEW.md`. The 256 MiB footprint is the working blocker. Eight pointer-seed/layout control jobs are also complete (7,920 samples), with a shared transition between the sampled spacings N=480 and N=512; see `results/v2-prefetch/review/REVIEW.md`. The first page-advice comparison completed (2,970 samples), but achieved only 6/256 MiB huge backing and is inconclusive as a full page-size control. The local verified-collapse rerun failed to obtain full native huge backing on node 0, after completing the enclave baseline. A separate native 4K/full-THP pair with memory on node 1 completed (1,980 samples) and preserved the coarse transition; see `results/v2-translation-node1/review/REVIEW.md`. All 16 instruction-width/alignment jobs are now complete (15,840 samples), preserving the 480–512 transition across the eight 256 MiB cases; 16 KiB controls have no comparable step. See `results/v2-frontend/review/REVIEW.md`. All eight overhead jobs are also complete (240 samples); the measured SGX zero-work scale is about 0.054 TSC ticks/load at 100,000 iterations, and primary timings remain uncorrected. See `results/v2-overhead/review/REVIEW.md`. The first fine sweep is complete (1,980 samples), resolving an observed 492–500 NOP transition region in both environments with the largest adjacent step at 496→500; SGX remains noisy. See `results/v2-fine/review/REVIEW.md`. The matched order-seed-2 repeat is also complete (another 1,980 samples), preserving the 492–500 region while retaining substantial SGX variability, including a larger isolated N=548 median spike. See `ROB_RESULTS_ARTEMISIA.md` for the consolidated finding. No additional routine Artemisia repeats are proposed for this claim; sibling activity remains uncontrolled. See `results/v2-translation/review/REVIEW.md`. No ROB capacity has been inferred. Proceed to PRF/TLB work after the ROB method is validated.

Retain remaining native-run metadata on Charnwood and Artemisia:

```bash
uname -r
gcc --version | head -n 1
lscpu -e=CPU,CORE,SOCKET,NODE,ONLINE
getconf PAGESIZE
cat /sys/kernel/mm/transparent_hugepage/enabled
```

Record exact SDK/runtime versions with eventual enclave benchmark runs. The successful sample is setup evidence, not a measured ROB, PRF, or TLB result.

### Platform sources

- Intel, [Core i7-6700 specifications](https://www.intel.com/content/www/us/en/products/sku/88196/intel-core-i76700-processor-8m-cache-up-to-4-00-ghz/specifications.html).
- Intel, [Sapphire Rapids product list](https://www.intel.com/content/www/us/en/ark/products/codename/126212/products-formerly-sapphire-rapids.html), including Xeon Gold 5420+ family, launch, cores, and per-processor L3 information.
- Intel, [Core i7-9700 specifications](https://www.intel.com/content/www/us/en/products/sku/191792/intel-core-i79700-processor-12m-cache-up-to-4-70-ghz/specifications.html).
- Intel, [SGX SDK for Linux overview](https://www.intel.com/content/www/us/en/developer/tools/software-guard-extensions/linux-overview.html).
- Linux kernel, [SGX documentation](https://docs.kernel.org/arch/x86/sgx.html).
- Observed runtime configuration and device permissions/access tests: the user's pasted shell output. No listed capacity inference has yet been measured.

## 4. Implementation sequence

### Stage 1 - Platform inventory and shared measurement framework

CPU model and x86-64 compatibility have been identified from the supplied records. Complete the remaining build, topology, page-policy, and enclave checks, then establish:

- A timer with accurately documented units and measurement boundaries.
- CPU selection/affinity and a record of SMT or other uncontrolled activity.
- Explicit warm-up and repeated-sampling procedures.
- Per-sample raw data with parameters and build identity.
- Separate reporting of success, failure, and inconclusive results.
- A plotting path that produces the same figures from saved inputs.

For x86, TSC ticks are an acceptable reporting unit; they must be labeled as TSC ticks rather than assumed to equal active core cycles. Timing units do not settle instruction-ordering questions, which must be handled separately. Other ISAs may need a different timer and benchmark backend.

### Stage 2 - Q4: ROB capacity

Develop a new benchmark implementation around the discussed principle of holding up retirement while younger instructions occupy entries, with an independent operation making the loss of overlap observable.

Before accepting a capacity estimate:

- Check the actual instruction sequence and dependency structure.
- Define the spacing convention and account for loop-control instructions.
- Confirm that the blocker lasts long enough under the actual memory conditions.
- Check that the observed limit can be attributed to the ROB rather than another allocation resource.
- Use an adequate sweep range; do not inherit the reviewed reference's ceiling of 199 without justification.

The earlier reference-code review found a 256 MiB address span with about 4 MiB of actively chased cache lines, assuming 64-byte lines. That is a warning about allocation-versus-footprint accounting, not a result for the new benchmark. Check the new implementation's actual accessed footprint and do not assume that every load reaches DRAM.

### Stage 3 - Q5: physical register capacity

Select and name a register class explicitly. A focused integer-register experiment is a possible first target if supported by the selected machines; testing every register class is not stated as a requirement.

Reuse suitable infrastructure from the ROB work while validating instruction-specific register allocation and dependencies. Explain whether the experiment identifies available speculative physical-register capacity, a lower bound, or total PRF size. Do not silently label an available speculative allocation budget as the entire register file: committed architectural mappings and implementation details can affect that relationship.

Q5 asks for PRF size, so any inference from the measured budget to a total must be justified. If the experiment only supports a narrower quantity, state that limitation and investigate further rather than claiming Q5 is automatically complete.

### Stage 4 - Q6: TLB levels and capacities

Develop a separate translation-focused capacity experiment. Record page size and the actual page/line access pattern. Identify evidence for distinct translation-capacity regions, and control competing data-cache and memory effects sufficiently to support the interpretation.

Do not label every timing knee as another TLB level. Explain what the observations support, what alternative explanations remain, and whether a level is not observable with the chosen method. Published specifications belong in a separately identified comparison, not in place of measurement.

The target here is translation hardware; incidental memory controls must not become a cache-reverse-engineering submission.

### Stage 5 - Repeat on the second machine and perform the enclave comparison

Complete each selected experiment on both machines, preserve raw samples, and prepare direct comparisons. Investigate unsupported behavior or an inconclusive result before deciding whether to revise the selected exercise combination.

### Stage 6 - Explain, package, and reproduce

Write a compact exercise-by-exercise report with plots, code snippets, method descriptions, side-by-side results, and limitations. Verify that another reader can rebuild the code and regenerate the figures using the included instructions and data.

## 5. Enclave requirement and access exception

Each selected experiment must be compared inside and outside an enclave on the same enclave-capable course machine where support/access permits. Identify the enclave platform and configuration, compare results and trends, and explain differences and challenges.

If support or access is unavailable, document the specific limitation. The ordinary experiments must still run on **two course machines per exercise**. An ordinary container or VM must not be represented as an enclave.

Check native/enclave workload and timer comparability. Do not assume that native executable-memory allocation, generated code, timers, or other facilities transfer unchanged into an enclave. Record whether transition overhead is included in a measured region.

## 6. Evidence and reporting template

For each selected question, include:

1. Question number, title, and point value.
2. What behavior or resource is being tested.
3. Actual instruction/data arrangement and a code snippet.
4. Timing units, sample procedure, and normalization.
5. Machine 1 and Machine 2 plots/results side by side.
6. The inferred quantity with uncertainty and a justification.
7. Alternative explanations and experimental controls.
8. Enclave/native comparison or documented access limitation.
9. A separately labeled comparison with published specifications, if used.

Suggested common raw-sample fields:

`experiment, run_id, machine_id, environment, cpu_id, source_revision, parameter_name, parameter_value, timer_unit, elapsed_ticks, work_count, sample_id, status`

Preserve additional experiment-specific parameters and the rules used to summarize or exclude samples. Do not fabricate measurements, capacity values, successful access checks, or resolved limitations.

## 7. AI-use record

Create and maintain an actual AI-use log in the final submission. An initial record should acknowledge the assistance relevant to the submitted work, including retained work from before the pivot.

| Phase | Assistance already provided | Verification / use to record |
| --- | --- | --- |
| Before the pivot | Literature suggestions; ROB mechanism and experimental-method discussion. | Which ideas/references are retained and how they were checked. |
| Before the pivot | Annotation and review of a supplied reference benchmark, including syntax/disassembly checks and pointer-cycle inspection. | This was not a timing run or a measured course-machine ROB result. Record any retained conclusions accurately. |
| Before the pivot | A Track A technical README. | The project is now Track B; identify any retained planning content. |
| Current restart | Recommended Q4/Q5/Q6 scope and this Track B work plan. | Question values and common requirements checked against the supplied assignment. Charnwood and Artemisia are the recommended pair; Artemisia's installed SDK and hardware debug enclave sample have now been validated by the user's successful run. |
| Platform review | Interpreted the supplied Charnwood/Crux/Artemisia CPU records and device-access tests, checked Intel CPU identification and SGX requirements, and recommended Charnwood/Artemisia. | Crux permission check failed; Artemisia permission check and hardware-mode debug SampleEnclave run passed. Exact version/topology metadata and custom timing benchmarks remain pending. |
| SGX hardware smoke test | Provided environment and hardware debug sample-build commands; interpreted the user's successful SampleEnclave output. | Retain the build/run output as platform validation, separate from benchmark measurements. |
| Implementation and analysis | To be updated as assistance occurs. | Record generated/modified code, debugging, interpretation, tests, and the student's verification and understanding. |

These entries record assistance; they do not establish that an experiment is complete. Track B permits AI use without a penalty for that use, but requires disclosure and understanding of all submitted work.

## 8. Completion checklist

- [ ] Final selected questions total at least 100 points and appear on the report's first page.
- [ ] Each selected exercise has measurements on two course machines.
- [ ] CPU model and microarchitecture are identified for every tested machine.
- [ ] Methods and relevant code snippets are included.
- [ ] Repeated measurements, plots, and explanations support the conclusions.
- [ ] Results for the two machines are presented side by side.
- [ ] Measured quantities and published specifications are separate.
- [ ] Unsupported features and access limitations are documented.
- [ ] Enclave/native comparisons are included where available; unavailability is documented accurately.
- [ ] The ordinary two-machine requirement is met regardless of enclave availability.
- [ ] The AI-use log reflects actual assistance, including retained earlier work.
- [ ] The student can explain the code, controls, measurements, and conclusions.
- [ ] ZIP contains the PDF report, source code, raw data, plotting scripts, and reproduction instructions.

Optional bonus work is outside the initial scope. The handout offers an eight-machine comparison with a proposed law/trend and justified scope/exceptions; complete the required selected exercises before expanding to that work.
