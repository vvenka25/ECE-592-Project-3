# ECE 592 Homework 3 — Overleaf source

Author: Varunaditya Venkatesan. Selected questions: Q1, Q2, Q3, Q4, Q5, Q8 — 105 points.

Project: https://www.overleaf.com/project/6aeeb80e5d4ccedd231a327b
Full source, raw evidence and reproduction: https://github.com/vvenka25/ECE-592-Project-3

## Compile

Set the main document to `main.tex` and use pdfLaTeX. Figures, generated tables
and source excerpts are included; compilation needs no Python, shell escape,
network fetch or files outside this ZIP. Locally, run pdfLaTeX twice.

## Put these files in the existing Overleaf project

Extract this ZIP and use the project's Upload files interface to upload the
extracted files/folders, preserving `figures/`, `generated/` and `snippets/`.
Select `main.tex` as the main document. Overleaf's separate Upload Project
operation creates a new project; use the existing project's file uploader
when updating the user-designated project.

Official instructions:
https://docs.overleaf.com/managing-projects-and-files/adding-files-to-a-project/uploading-files-to-a-project

No authenticated Overleaf editing connection was available to the agent;
this source archive was created and locally compile-tested, not directly
uploaded. The project link is the normal URL and omits its sharing token.

## Regenerate the figures

The included SVGs and `figure-source/make_report_artifacts.py` document the
original HW3 diagrams/plots. To rerun the Python generator, use the full
repository checkout, restore its raw data, and execute
`python3 report/make_report_artifacts.py` there. The minimal Overleaf bundle
does not contain the benchmark's raw data or all source imports.
`provenance/` records input hashes and excerpt origins. The AI-use log is
included for disclosure. Project 1 data/prose/artwork are excluded.
